import time
import os
import datetime
import platform

log = print
from watchdog.observers import Observer
from watchdog.events import PatternMatchingEventHandler


def test_guas(path):
    guas = []
    for root, dirs, files in os.walk(path):
        for name in files:
            if name.startswith('test_') and name.endswith('.gua'):
                fullpath = os.path.join(root, name)
                guas.append(fullpath)
    return guas


def run_gua(fullpath):
    os_name = platform.system()
    if os_name == 'Windows':
        cmd = f'chcp 65001 && c:\\gualang_ide\\portable-data\\data\\user-data\\gualang\\gualang.exe \"{fullpath}\"'
    else:
        cmd = f'/Applications/gualang/code-portable-data/user-data/gualang/gualang.mac \"{fullpath}\"'
    os.system(cmd)


class AutoTest(PatternMatchingEventHandler):
    patterns = [
        # "*.py",
        "*.gua",
        "*.a16",
    ]

    def process(self, event):
        log('auto test', os.getcwd())
        log(datetime.datetime.now().strftime("%Y/%m/%d %I:%M %p"))
        self.run_test_guas()

    @staticmethod
    def run_test_guas():
        path = os.path.abspath(__file__)
        dirname = os.path.dirname(path)
        guas = test_guas(dirname)
        for gua in guas:
            run_gua(gua)

    def on_modified(self, event):
        self.process(event)


def main():
    path = '.'
    observer = Observer()
    observer.schedule(AutoTest(), path=path, recursive=True)
    observer.start()

    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        observer.stop()

    observer.join()


if __name__ == '__main__':
    main()
