gualang auto test 运行方法

- 打开 gualang ide

- 运行任意 .gua 文件，来打开 vscode 内置终端

- 在内置终端中执行下面的命令安装 python 的 watchdog 包
pip3 install watchdog -i https://pypi.tuna.tsinghua.edu.cn/simple

- 在内置终端中执行下面的命令来运行 auto_test

win 用户执行：
py.exe auto_test.py

mac 用户执行
python3 auto_test.py


运行之后修改目录下的任意 .gua 文件
都会自动运行 test_ 开头的 .gua 文件