# coding: utf-8

def log(*arg, **kwarg):
    print(*arg, **kwarg)



def parseAppExt(d, index):
    log('应用程序控制拓展', index)
    # GIF中扩展块都以0x21 (33) 开始，后一个字节是扩展标签，标识扩展用途。
    # 33
    log(d[index])
    # ff
    log(d[index + 1])
    # 应用程序信息大小  11
    appSize = d[index + 2]
    log('应用程序信息大小:', d[index + 2])
    # NETSCAPE2.0  [78, 69, 84, 83, 67, 65, 80, 69, 50, 46, 48]
    log(d[index+3: index+3+appSize], index+3, index+3+appSize)
    # 应用程序数据大小  3
    log(d[index+3+appSize])
    # 索引
    log(d[index+3+appSize + 1])
    # 数据 [0, 0]
    log(d[index+3+appSize + 2: index+3+appSize + 4])
    # 结束符 0
    log(d[index+3+appSize + 4])

    return index+3+appSize + 5



# 0 + 1 + 2
# [1,1,1,2]
# 图形控制扩展(Graphic Control Extension)
def parstGraphicExt(d, index):
    log('图形控制扩展', index)
    # 图形控制扩展标志 0x21(33)
    log(d[index])
    # 拓展类型标志 0xf9(249)
    log(d[index+1])
    # 块大小 4
    log(d[index+2])
    # 
    data = d[index+3]
    log(data)
    type = (data & 0b00011100) >> 2
    i =    (data & 0b00000010) >> 1
    t = (data & 0b00000001) 
    log('type i t:', type, i, t)
    # 延时时间 [10, 0]
    log(d[index+4: index+6], d[index+4], d[index+5])
    # 透明色索引  0xff
    log(d[index+6])
    # 结束符 0
    log(d[index+7])
    return index + 8



def parseImageData(d, index):
    log('图像数据', index)
    # 图像数据 第一个字节是 LZW 最小编码大小，
    # log(d[index])
    log( '{}: [{}]'.format(index, d[index]) ) 
    # 第二个字节是图像数据的大小
    next = index + 1
    allData = []
    for j in range(next, len(d)):
        size = d[next]
        log( 'next {}: [{}]'.format(next, d[next]) ) 
        if size == 0:
            break
        
        imgData = []
        for i in range(next + 1, next + 1 + size):
            imgData.append(d[i])
        
        # log('imagedata', len(imgData))
        allData.extend(imgData)
        next = next + size + 1
    
    log('allData', allData)
    return next + 1


def parseImgDescriptor(d, index):
    log('图像标识符', index) 
    # 图像标识符(Image Descriptor)  0x2c  44 
    log( '{}: [{}]'.format(index, d[index]) ) 
    # x方向偏移量 d[index+1: index+3]
    log('{}-{}: [{}, {}]'.format(index+1, index+2, d[index+1], d[index+2]))
    # y方向偏移量 (d[index+3: index+5]
    log('{}-{}: [{}, {}]'.format(index+3, index+4, d[index+3], d[index+4]))
    # 图像宽度 d[index+5: index + 7]
    log('{}-{}: [{}, {}]'.format(index+5, index+6, d[index+5], d[index+6]))
    # log( d[index+5], d[index+6])
    # 图像高度 d[index+7: index + 9]
    log('{}-{}: [{}, {}]'.format(index+7, index+8, d[index+7], d[index+8]))
    # log( d[index+7], d[index+8])
    # 如果上面的局部颜色列表标志位为1，那么局部颜色列表会排列在图像描述符后面，它只对紧跟在它之后的图像数据有效。
    # 如果局部颜色列表标志位为0，那么图像数据将使用全局颜色列表索引颜色。
    # 局部颜色列表的大小计算方法和像素颜色格式与全局颜色列表相同。
    # m i s r pixel
    data = d[index+9]
    log( '{}: [{}]'.format(index+9, d[index+9]) ) 
    m = (data & 0b10000000) >> 7
    i = (data & 0b01000000) >> 6 
    s = (data & 0b00100000) >> 5
    r = (data & 0b00011000) >> 4
    pixel = (data & 0b00000111)
    log('m i s r pixel:', m, i, s, r, pixel)
    return index + 10


def paseImage(d, index):
    # 图形控制扩展 0x21(33)
    index3 = parstGraphicExt(d, index)
    # 图像标识符
    index4 = parseImgDescriptor(d, index3)
    #局部颜色列表  该图片为空
    # 图片数据
    index5 = parseImageData(d, index4)
    return  index5




def gif():
    with open('doge.gif', 'rb' ) as f:
        d = f.read()
    
    # log(d)
    # 长度
    log(len(d))

    log(d[0:6])

    #
    # 2 字节宽度，2 字节高度  [73, 0] [65, 0]
    # 宽 73 高 65
    log(d[6:10], d[6], d[8])

    data = d[10]
    log('-------', data)
    m = (data & 0b10000000) >> 7
    cr = (data & 0b01110000) >> 4 
    s = (data & 0b00001000) >> 3
    pixel = (data & 0b00000111)
    log('m cr s pixel ', m, cr, s, pixel)

    # 背景色 [0]
    log(d[11])

    # 像素宽高比 [0]
    log(d[12])

    size = 2 ** (pixel + 1)
    log('size:', size)

    # 调色板
    colorTable = []
    index = 1
    # RGB
    for i in range(13, size * 3 + 13, 3):
        r = d[i]
        g = d[i+1]
        b = d[i+2]
        color = [r, g, b]
        colorTable.append(color)

    log('table', len(colorTable), colorTable[0:10])
    log('colorTable', colorTable)
    imgIndex = size * 3 + 13 

    # 开始解析子程序
    log('---开始解析子程序')
    ext = d[imgIndex]

    while ext != 0x3b:
        type = d[imgIndex+1]    
        if type == 0xff:
            imgIndex = parseAppExt(d, imgIndex)
        elif type == 0xf9:
            imgIndex = paseImage(d, imgIndex)
        else:
            break
        
        ext = d[imgIndex] 

    log('解析结束', imgIndex, len(d), d[imgIndex])

gif()